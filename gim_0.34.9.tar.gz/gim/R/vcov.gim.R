
vcov.gim <- function(object, ...){
  
  object$vcov
  
}
